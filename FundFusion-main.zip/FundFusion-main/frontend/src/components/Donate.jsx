
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button, Table, Form, Alert } from "react-bootstrap";

function Donate() {
  const API_URL = "http://localhost:3000/api";

  const [donations, setDonations] = useState([]);
  const [form, setForm] = useState({
    donor_name: "",
    amount: "",
    project_id: "",
    user_id: "",
  });
  const [editId, setEditId] = useState(null);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    fetchDonations();
  }, []);

  function fetchDonations() {
    axios
      .get(`${API_URL}/donations`)
      .then((res) => {
        setDonations(res.data.donations);
      })
      .catch((err) => {
        console.error(err);
      });
  }

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prevForm) => ({
      ...prevForm,
      [name]: value,
    }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    const { donor_name, amount, project_id, user_id } = form;

    if (!donor_name || !amount || !project_id || !user_id) {
      setError("All fields are required.");
      return;
    }

    if (editId) {
      // Update
      axios
        .put(`${API_URL}/donation/:${editId}`, form)
        .then(() => {
          setSuccessMessage("Donation updated successfully.");
          resetForm();
          fetchDonations();
        })
        .catch((err) => {
          console.error(err);
          setError("Error updating donation");
        });
    } else {
      // Create
      axios
        .post(`${API_URL}/donate`, form)
        .then(() => {
          setSuccessMessage("Donation added successfully.");
          resetForm();
          fetchDonations();
        })
        .catch((err) => {
          console.error(err);
          setError("Error adding donation");
        });
    }
  }

  function handleEdit(donation) {
    setForm({
      donor_name: donation.donor_name,
      amount: donation.amount,
      project_id: donation.project_id,
      user_id: donation.user_id,
    });
    setEditId(donation.id);
  }

  function handleDelete(id) {
    if (window.confirm("Are you sure you want to delete this donation?")) {
      axios
        .delete(`${API_URL}/donation/:${id}`)
        .then(() => {
          fetchDonations();
        })
        .catch((err) => {
          console.error(err);
        });
    }
  }

  function resetForm() {
    setForm({
      donor_name: "",
      amount: "",
      project_id: "",
      user_id: "",
    });
    setEditId(null);
    setError("");
  }

  return (
    <div className="container mt-4">
      <h2>{editId ? "Edit Donation" : "Add Donation"}</h2>

      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Donor Name</Form.Label>
          <Form.Control
            type="text"
            name="donor_name"
            placeholder="Donor Name"
            value={form.donor_name}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Amount</Form.Label>
          <Form.Control
            type="number"
            name="amount"
            placeholder="Amount"
            value={form.amount}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Project ID</Form.Label>
          <Form.Control
            type="number"
            name="project_id"
            placeholder="Project ID"
            value={form.project_id}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>User ID</Form.Label>
          <Form.Control
            type="number"
            name="user_id"
            placeholder="User ID"
            value={form.user_id}
            onChange={handleChange}
          />
        </Form.Group>

        {error && <Alert variant="danger">{error}</Alert>}
        {successMessage && <Alert variant="success">{successMessage}</Alert>}

        <Button variant="primary" type="submit">
          {editId ? "Update" : "Donate"}
        </Button>
      </Form>

      <h3 className="mt-4">All Donations</h3>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Donor</th>
            <th>Amount</th>
            <th>Project ID</th>
            <th>User</th>
            <th>Donation Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {donations.map((don) => (
            <tr key={don.id}>
              <td>{don.id}</td>
              <td>{don.donor_name}</td>
              <td>{don.amount}</td>
              <td>{don.project_id}</td>
              <td>{don.first_name} {don.last_name}</td>
              <td>{new Date(don.donation_date).toLocaleString()}</td>
              <td>
                <Button
                  variant="warning"
                  className="me-2"
                  onClick={() => handleEdit(don)}
                >
                  Edit
                </Button>
                <Button
                  variant="danger"
                  onClick={() => handleDelete(don.id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
}

export default Donate;
