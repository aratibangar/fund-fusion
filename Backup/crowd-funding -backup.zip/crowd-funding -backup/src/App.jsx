import { NavigationBar } from "./components/NavigationBar"
import { FooterCon } from "./components/FooterCon"
import { Home } from "./components/Home"


function App() {
  

  return (
   <>
      <NavigationBar />
      
      <FooterCon />
    </>
  )
}

export default App
